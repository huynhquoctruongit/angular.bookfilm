import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-listnew',
  templateUrl: './item-listnew.component.html',
  styleUrls: ['./item-listnew.component.css']
})
export class ItemListnewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
