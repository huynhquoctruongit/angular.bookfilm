//khai báo đối tượng người dùng
export class User{
    TaiKhoan:string;
    MatKhau:string;
    Email:string;
    SoDT:string;
    MaNhom:string;
    MaLoaiNguoiDung:string;
    HoTen:string;   
}
